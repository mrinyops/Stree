import { Button, StyleSheet, Text, View } from 'react-native';

import { useAuth } from '@/lib';

export default function HomeScreen() {
  const signOut = useAuth((s) => s.signOut);
  const user = useAuth((s) => s.user);

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>👋 Welcome to Stree</Text>
      <Text style={styles.subtext}>
        {user?.email ? `Logged in as ${user.email}` : 'Not signed in'}
      </Text>

      <Button title="Sign Out" onPress={signOut} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  heading: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
  subtext: { fontSize: 16, color: '#555', marginBottom: 20 },
});
