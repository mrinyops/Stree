module.exports = require('react-native-keyboard-controller/jest');
