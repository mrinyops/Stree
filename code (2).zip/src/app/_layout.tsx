import { Stack } from 'expo-router';
import { useEffect } from 'react';

import { hydrateAuth, useAuth } from '@/lib';

export default function RootLayout() {
  const status = useAuth.use.status();

  useEffect(() => {
    hydrateAuth();
  }, []);

  return (
    <Stack screenOptions={{ headerShown: false }}>
      {status === 'signIn' ? (
        <Stack.Screen name="(app)" />
      ) : (
        <Stack.Screen name="(auth)" />
      )}
    </Stack>
  );
}
