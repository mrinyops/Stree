import { useState } from 'react';
import { Button, Text, TextInput, View } from 'react-native';

import { useAuth } from '@/lib';

export default function Login() {
  const signIn = useAuth.use.signIn();
  const status = useAuth.use.status();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // 🔑 Replace with Supabase later
    signIn({ accessToken: 'demo-token' });
  };

  return (
    <View className="flex-1 justify-center gap-4 bg-white p-6">
      <Text className="mb-4 text-2xl font-bold">Login</Text>
      <TextInput
        className="rounded border p-2"
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
      />
      <TextInput
        className="rounded border p-2"
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="Sign In" onPress={handleLogin} />
      <Text className="text-secondary-500 mt-4">Status: {status}</Text>
    </View>
  );
}
