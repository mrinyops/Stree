import React from 'react';

import { Text, View } from '@/components/ui';

import { Title } from './title';

export const Typography = () => {
  return (
    <>
      <Title text="Typography" />
      <View className="mb-4 flex-col">
        <Text className="text-3xl  tracking-tight">
          H1: Lorem ipsum dolor sit
        </Text>
        <Text className="text-2xl ">H2: Lorem ipsum dolor sit</Text>
        <Text className="text-xl ">H3: Lorem ipsum dolor sit</Text>
        <Text className="text-lg ">H4: Lorem ipsum dolor sit</Text>
        <Text className="text-base">
          Lorem ipsum dolor sit amet consectetur, adipisicing elit. Cumque quasi
          aut, expedita tempore ratione quidem in, corporis quia minus et
          dolorem sunt temporibus iusto consequatur culpa. Omnis sequi debitis
          recusandae?
        </Text>
      </View>
    </>
  );
};
