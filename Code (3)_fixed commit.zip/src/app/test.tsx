import { Text, View } from 'react-native';

export default function TestScreen() {
  return (
    <View className="flex-1 items-center justify-center bg-red-500">
      <Text className="text-3xl font-bold text-white">
        🚀 NativeWind Works!
      </Text>
    </View>
  );
}
